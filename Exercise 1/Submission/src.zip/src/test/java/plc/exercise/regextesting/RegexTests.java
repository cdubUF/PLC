package plc.exercise.regextesting;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Map;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public final class RegexTests {

    @ParameterizedTest
    @MethodSource
    public void testEmail(String test, String input, boolean matches) {
        test(input, Regex.EMAIL, matches);
    }

    public static Stream<Arguments> testEmail() {
        return Stream.of(
            Arguments.of("Alphanumeric", "thelegend27@gmail.com", true),
            Arguments.of("UF Domain", "otherdomain@ufl.edu", true),
            Arguments.of("Subdomain", "otherdomain@cise.ufl.edu", false),
            Arguments.of("Another Subdomain", "otherdomain@eng.ufl.edu", false),
            Arguments.of("Another Another Subdomain", "otherdomain@admin.ufl.edu", false),
            Arguments.of("Missing Domain Dot", "missingdot@gmailcom", false),
            Arguments.of("Symbols", "symbols#$%@gmail.com", false),
            // Matching (True)
            Arguments.of("Basic email", "email@example.com", true),
            Arguments.of("Gmail address", "thelegend27@gmail.com", true),
            Arguments.of("Numbers and dots", "user.name123@domain.net", true),
            Arguments.of("Hyphen in domain", "hello-world@my-site.org", true),
            Arguments.of("Underscore in local part", "first_last@service.com", true),
            // Non-Matching (False)
            Arguments.of("Missing dot", "email@missingdot", false),
            Arguments.of("Illegal chars in local part", "#$%@example.com", false),
            Arguments.of("No domain", "plainaddress@", false),
            Arguments.of("No @ symbol", "justtext.com", false),
            Arguments.of("TLD too long", "user@domain.toolong", false),
            // Missing Test Cases
            Arguments.of("Empty", "", false),
            Arguments.of("Underscore in Domain", "user@do_main.com", false),
            Arguments.of("Empty Domain", "user@,com", false),
            Arguments.of("Missing Domain", "user@", false),
            Arguments.of("Uppercase TLD", "user@domain.COM", false),
            Arguments.of("Dash", "a.b_c-d@x-1.io", true),
            Arguments.of("Classic com", "john.doe123@my-site.com", true),
            Arguments.of("Email - Numbers in Address", "123@example.com", true)

        );
    }

    @ParameterizedTest
    @MethodSource
    public void testSearchTerm(String test, String input, boolean matches) {
        test(input, Regex.SEARCH_TERM, matches);
    }

    public static Stream<Arguments> testSearchTerm() {
        return Stream.of(
            Arguments.of("Equal", "search", true),
            Arguments.of("Substring", "google search \"lmgtfy\"", true),
            Arguments.of("Spaces", "use arch", false),
            // Matching (True)
            Arguments.of("Exact word", "search", true, Map.of()),
            Arguments.of("Search in middle", "google search engine", true),
            Arguments.of("Search with quotes", "really search \"ANYTHING\"", true),
            Arguments.of("Search at start", "search PARTY! tonight", true),
            Arguments.of("Search at end", "how do I search?", true),
            // Non-Matching (False)
            Arguments.of("Partial overlap", "use arch", false),
            Arguments.of("Letters scrambled", "sreach is wrong", false),
            Arguments.of("Missing one letter", "serch function", false),
            Arguments.of("Different word", "lookup tool", false),
            Arguments.of("Empty string", "", false),
            // Newline test case
            Arguments.of("Newlines", "hello\nsearch\nworld", true)
        );
    }

    @ParameterizedTest
    @MethodSource
    public void testDiscountCsv(String test, String input, boolean matches) {
        test(input, Regex.DISCOUNT_CSV, matches);
    }

    public static Stream<Arguments> testDiscountCsv() {
        return Stream.of(
            Arguments.of("Single", "single", true),
            Arguments.of("Multiple", "one,two,three", true),
            Arguments.of("Spaces", "first , second", true),
            Arguments.of("Missing Value", "first,,second", false),
            // MATCHING (TRUE)
            Arguments.of("Single value", "kappa", true),
            Arguments.of("Two values, no spaces", "foo,bar", true),
            Arguments.of("Three values", "what,it,do", true),
            Arguments.of("Spaces around comma", "excuse , me , miss", true),
            Arguments.of("Mixed spacing", "a,  b ,c", true),
            // Non-Matching False
            Arguments.of("Empty String", "", false), // Empty CSV File?
            Arguments.of("Dangling comma at end", "last,", false),
            Arguments.of("Double comma (Missing Value)", "can,,we,talk", false),
            Arguments.of("Whitespace Only", "yo, , baby", false), // Value 2 = " ", Does this make it true or false?
            Arguments.of("Leading Comma", ",start", false)

        );
    }

    @ParameterizedTest
    @MethodSource
    public void testDateNotation(String test, String input, boolean matches, Map<String, String> groups) {
        var matcher = Regex.DATE_NOTATION.matcher(input);
        Assertions.assertEquals(matches, matcher.matches());
        if (matches) {
            Assertions.assertEquals(groups, Regex.getGroups(matcher));
        }
    }

    public static Stream<Arguments> testDateNotation() {
        return Stream.of(
                Arguments.of("Month/Day", "8/25", true, Map.of(
                "month", "8", "day", "25"
            )),
            Arguments.of("Month/Day/Year", "8/25/2025", true, Map.of(
                "month", "8", "day", "25", "year", "2025"
            )),
            Arguments.of("Month Leading Zero", "08/25", false, Map.of()),
            Arguments.of("Missing Year", "8/25/", false, Map.of()),

            //Non-Matching (False)
            Arguments.of("Month leading zero", "01/25", false, Map.of()),
            Arguments.of("Day Leading Zero", "8/09", false, Map.of()),
            Arguments.of("Trailing slash missing year", "4/10/", false, Map.of()),
            Arguments.of("Out of range month", "13/5", false, Map.of()),
            Arguments.of("Out of range day", "9/32/2025", false, Map.of()),

            // Matching (True)
            Arguments.of("Single digit month/day", "3/7", true, Map.of("month", "3", "day", "7")),
            Arguments.of("end of year", "12/31", true, Map.of("month", "12", "day", "31")),
            Arguments.of("With year", "11/5/1999", true, Map.of("month", "11", "day", "5", "year", "1999")),
            Arguments.of("Leap day allowed", "2/29/2020", true, Map.of("month", "2", "day", "29", "year", "2020")),
            Arguments.of("Another valid date", "7/14/1776", true, Map.of("month", "7", "day", "14", "year", "1776"))
            //TODO: Test coverage (*minimum* 5 matching, 5 non-matching)


        );
    }

    @ParameterizedTest
    @MethodSource
    public void testNumber(String test, String input, boolean matches) {
        test(input, Regex.NUMBER, matches);
    }

    public static Stream<Arguments> testNumber() {
        return Stream.of(
                // Simple
                Arguments.of("Decimal 1", "1.2", true),
                Arguments.of("Decimal 2", "40.1238172831723981283129839812", true),
                Arguments.of("Decimal 3", "1.2.", false),
                Arguments.of("Decimal 4", ".90", false),
                Arguments.of("Int 1", "1", true),
                Arguments.of("Int 2", "60128", true),

                // +/- numbers
                Arguments.of("Positive Num", "+1", true),
                Arguments.of("Positive Decimal", "+5.5", true),
                Arguments.of("Negative Num", "-5", true),
                Arguments.of("Negative Decimal", "-5.5", true),

                // Exponents
                Arguments.of("Exponent Only", "5e", false),
                Arguments.of("Positive Exponent", "6e2", true),
                Arguments.of("Decimal w/ +Exp", "-5.5e+2", true),
                Arguments.of("Decimal w/ -Exp", "5.5e-2", true),

                // Added edge cases
                Arguments.of("Uppercase E", "12E10", false),
                Arguments.of("Signed exponent", "+3e+07", true),
                Arguments.of("Zero", "0", true),
                Arguments.of("Decimal w/ leading zero", "0.90", true),
                Arguments.of("Signed dec + e", "-0.0e-10", true),

                Arguments.of("Just sign", "+", false),
                Arguments.of("Dot only", ".", false),
                Arguments.of("Leading-dot decimal", ".5", false),
                Arguments.of("Missing exp digits", "10e-", false),
                Arguments.of("Multiple dots", "1.2.3", false),
                Arguments.of("Decimal exponent", "1e2.3", false)
        );
    }

    @ParameterizedTest
    @MethodSource
    public void testString(String test, String input, boolean matches) {
        test(input, Regex.STRING, matches);
    }

    public static Stream<Arguments> testString() {
        // Matching
        return Stream.of(
                // MATCH (should be true)
                Arguments.of("Empty", "\"\"", true),
                Arguments.of("Simple String", "\"Hello_World123\"", true),
                Arguments.of("Escaped quote", "\"quote: \\\"ok\\\"\"", true),
                Arguments.of("Escaped backslashes", "\"slashes: \\\\path\\\\file\"", true),
                Arguments.of("Escaped newline", "\"line\\nwrap\"", true),

                // NON-MATCH (should be false)
                Arguments.of("Unterminated", "\"unterminated", false),
                Arguments.of("Actual newline inside", "\"has\nnewline\"", false),
                Arguments.of("Invalid escape \\e", "\"bad\\escape\"", false),
                Arguments.of("No quotes at all", "no quotes", false),
                Arguments.of("Bare backslash before space", "\"backslash \\ inside\"", false)

        );
    }

    private static void test(String input, Pattern pattern, boolean matches) {
        Assertions.assertEquals(matches, pattern.matcher(input).matches());
    }

}
