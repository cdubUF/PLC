package plc.exercise.regextesting;

import java.io.File;
import java.io.FileFilter;
import java.util.Objects;
import java.util.regex.Pattern;

public class RegexFileFilter implements FileFilter {

    private final Pattern regex;
    private final boolean filename;

    public RegexFileFilter(Pattern regex, boolean filename) {
        this.regex = regex;
        this.filename = filename;
    }

    @Override
    public boolean accept(File pathname) {
        if (pathname == null) return false;
        String target = filename ? pathname.getName() : pathname.getPath(); // ? = if / else so if (filename) -> path.getName() else -> pathname.getPath()
        return regex.matcher(target).matches();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof RegexFileFilter)) return false;
        RegexFileFilter other = (RegexFileFilter) o;
        return filename == other.filename
                && Objects.equals(regex.pattern(), other.regex.pattern())
                && regex.flags() == other.regex.flags();
    }

    @Override
    public int hashCode() {
        return Objects.hash(regex.pattern(), regex.flags(), filename);
    }

    @Override
    public String toString() {
        return "RegexFileFilter{pattern=" + regex.pattern()
                + ", flags=" + regex.flags()
                + ", filename=" + filename + "}";
    }

    public static File[] listJavaFiles(File directory) {
        if (directory == null || !directory.isDirectory()) return new File[0];
        return directory.listFiles(new RegexFileFilter(Pattern.compile(".*\\.java$"), true));
    }
}
